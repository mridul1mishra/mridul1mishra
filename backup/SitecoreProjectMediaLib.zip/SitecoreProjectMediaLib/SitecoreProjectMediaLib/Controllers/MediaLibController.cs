﻿using ExcelDataReader;
using Sitecore.Globalization;
using Sitecore.Resources.Media;
using System;
using System.IO;
using System.Web.Mvc;
using Sitecore.Data.Items;

namespace SitecoreProjectMediaLib.Controllers
{
    public class MediaLibController : Controller
    {
        // GET: MediaLib
        public ActionResult Index()
        {
            return View();
        }
        public void DetachMedia()
        {
            string fileName = @"C:\ExcelImport\ImportExcel.xlsx";
            Language lang = Sitecore.Globalization.Language.Parse("zh-HK");
            using (var stream = System.IO.File.Open(fileName, FileMode.Open, FileAccess.Read))
            {

                IExcelDataReader reader;
                reader = ExcelDataReader.ExcelReaderFactory.CreateReader(stream);
                // reader.IsFirstRowAsColumnNames
                var conf = new ExcelDataSetConfiguration
                {
                    ConfigureDataTable = _ => new ExcelDataTableConfiguration
                    {
                        UseHeaderRow = true
                    }
                };
                var dataSet = reader.AsDataSet(conf);
                var dataTable = dataSet.Tables[0];
                for (int rw = 0; rw <= dataTable.Rows.Count; rw++)
                {
                    ExcelData exdata = new ExcelData();
                    exdata.Name = dataTable.Rows[rw][0].ToString();
                    exdata.FileType = dataTable.Rows[rw][1].ToString();
                    exdata.CMSPath = dataTable.Rows[rw][2].ToString();
                    exdata.URL = dataTable.Rows[rw][3].ToString();
                    var filewithextension = exdata.Name + '.' + exdata.FileType;

                    byte[] fileContent = null;
                    try
                    {
                        System.IO.FileStream fs = new System.IO.FileStream(exdata.URL, System.IO.FileMode.Open, System.IO.FileAccess.Read);
                        System.IO.BinaryReader binaryReader = new System.IO.BinaryReader(fs);
                        long byteLength = new System.IO.FileInfo(exdata.URL).Length;
                        fileContent = binaryReader.ReadBytes((Int32)byteLength);
                        fs.Close();
                        fs.Dispose();
                        AddMediaItem(fileContent, exdata.CMSPath, filewithextension, lang);
                    }

                    catch (Exception ex)
                    {
                        Sitecore.Diagnostics.Log.Error("Medialib dummy log", ex, this);
                    }


                }
            }
        }




        public static Item AddMediaItem(byte[] fileContent, string fullpath, string fileNameWithExtension, Language language)
        {
            try
            {
                var db = Sitecore.Configuration.Factory.GetDatabase("master");
                var options = new MediaCreatorOptions();
                options.FileBased = false;
                options.IncludeExtensionInItemName = false;
                options.OverwriteExisting = true;
                options.Versioned = true;
                options.Destination = fullpath;
                options.Database = db;
                options.Language = language;



                var creator = new MediaCreator();
                var fileStream = new MemoryStream(fileContent);



                var mediaItem = db.GetItem(fullpath, language);

                if (mediaItem != null)
                {
                    using (new Sitecore.SecurityModel.SecurityDisabler())
                    { //update a new item
                        var updatedItem = creator.AttachStreamToMediaItem(fileStream, fullpath, fileNameWithExtension,
                        options);
                        updatedItem.Editing.BeginEdit();
                        updatedItem.Editing.EndEdit();
                        return updatedItem;
                    }

                }
                return null;

            }
            catch (Exception ex)
            {
                return null;
            }
        }

        public class ExcelData
        {
            public string Name { get; set; }
            public string FileType { get; set; }
            public string CMSPath { get; set; }
            public string URL { get; set; }
            public string Size { get; set; }
            public string Width { get; set; }
            public string Height { get; set; }
        }
    }
}